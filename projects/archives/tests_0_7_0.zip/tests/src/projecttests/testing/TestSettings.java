package projecttests.testing;

public record TestSettings(int maxThreads, int timeout, int retries) {
    public static final String DEFAULT_MAX_THREADS = "50";
    public static final String DEFAULT_TIMEOUT = "300";
    public static final String DEFAULT_RETRIES = "1";
}
