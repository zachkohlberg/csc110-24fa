package projecttests.testing;

import java.util.List;

/** Represents a single line of output and whether it matched with another line. */
public record OutputLine(String line, LineStatus status) {
    @Override
    public String toString() {
        return "%-20s%s".formatted(status(), line());
    }

    @Override
    public boolean equals(Object other) {
        if (other instanceof OutputLine o) {
            return line().equals(o.line()) && status().equals(o.status());
        }
        return false;
    }

    public boolean linesEqual(OutputLine other) {
        return other != null && line().trim().equals(other.line().trim());
    }

    public OutputLine withStatus(LineStatus status) {
        return new OutputLine(line(), status);
    }

    public static List<OutputLine> uncheckedList(List<String> lines) {
        return lines.stream().map(line -> new OutputLine(line, LineStatus.UNCHECKED)).toList();
    }

    public static boolean allOkay(List<List<OutputLine>> lineGroups) {
        for (List<OutputLine> lines : lineGroups) {
            if (lines.stream()
                    .anyMatch(
                            line ->
                                    line.status() == LineStatus.ERROR
                                            || line.status() == LineStatus.UNCHECKED)) {
                return false;
            }
        }
        return true;
    }
}
