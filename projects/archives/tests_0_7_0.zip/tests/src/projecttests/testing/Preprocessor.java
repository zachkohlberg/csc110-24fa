package projecttests.testing;

import projecttests.Main;
import projecttests.TestingException;
import projecttests.logging.Logger;
import projecttests.util.FileIO;
import projecttests.util.Project;
import projecttests.util.Strings;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/** Prepares student code for testing. */
public class Preprocessor {
    private Project project;
    private Path programPath, backupPath;
    private List<String> studentCode, warnIfCodeContains;

    public Preprocessor(Project project) {
        this(project, Collections.emptyList());
    }

    public Preprocessor(Project project, List<String> warnIfCodeContains) {
        this.project = project;
        this.warnIfCodeContains = warnIfCodeContains;

        programPath = Main.settings().studentSrcPath().resolve(project.programRelativeFilePath());
        backupPath =
                Main.settings().studentBackupsPath().resolve(project.programRelativeFilePath());
    }

    public List<String> studentCode() {
        return studentCode;
    }

    public void run(String packageId) throws TestingException {
        if (!project.checkProjectFiles()) {
            throw new TestingException(
                    "Your program's path appears to differ in case from the expected path. Make"
                            + " sure you named all files and folders in your projects folder as"
                            + " directed!");
        }

        Logger.info("Running preprocessor to prepare student code for test.");

        studentCode =
                FileIO.loadOrElseThrow(
                        project.programFilePath(),
                        () -> new TestingException("Failed to load file!"));

        Logger.info("Saving backup of student program");

        try {
            Files.createDirectories(backupPath.getParent());
            Files.write(
                    backupPath,
                    studentCode,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException e) {
            Logger.error(e, "IOException while saving backup of student program").print();
        }

        Logger.info("Cleaning student code");

        studentCode = Processing.cleanProgram(studentCode);

        Logger.infoFormat("Cleaned student code:\n%s", Strings.join(studentCode, "\n"));

        warnIfCodeContains.stream()
                .filter(code -> studentCode.stream().anyMatch(line -> line.contains(code)))
                .forEach(
                        code ->
                                Logger.warn(
                                                "Student code appears to contain "
                                                        + code
                                                        + ", which may"
                                                        + " cause problems during the test.")
                                        .print());

        Processing.createModifiedProgram(studentCode, programPath, packageId);

        if (project.compiles()) {
            compile();
        }
    }

    public void compile() throws TestingException {
        try {
            ProcessBuilder builder =
                    new ProcessBuilder(
                            "javac",
                            "-nowarn",
                            "-source",
                            "19",
                            "-target",
                            "19",
                            "--source-path",
                            Main.settings().studentSrcPath().toString(),
                            "--class-path",
                            Main.settings().binPath().toString(),
                            "-d",
                            Main.settings().studentBinPath().toString(),
                            programPath.toString());

            Process javac = builder.start();
            javac.waitFor();

            try (Scanner err = new Scanner(javac.getErrorStream())) {
                if (err.hasNextLine()) {
                    StringBuilder errMessage = new StringBuilder();
                    errMessage.append("Failed to compile project!\n");
                    while (err.hasNextLine()) {
                        errMessage.append(err.nextLine());
                        errMessage.append('\n');
                    }
                    err.close();
                    throw new TestingException(errMessage.toString());
                }
            }
        } catch (Exception e) {
            throw new TestingException("Exception when compiling project!", e);
        }
    }
}
