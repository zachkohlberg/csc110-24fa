package projecttests.testing.input;

import java.util.function.Function;

/** Represents input types for project 1 tests. */
public record Project1Input(
        String userInputScanner,
        String playerName,
        String characterName,
        String characterAncestry,
        String characterClass,
        Integer level,
        Integer proficiency,
        Integer hitPoints,
        Integer armorClass,
        Boolean rollHp,
        int[] abilityScores,
        int[] abilityModifiers,
        String[] skillNames,
        int[] skillModifiers,
        Long seed)
        implements ProjectInput {
    @Override
    public String toString() {
        return display();
    }

    public String display() {
        StringBuilder builder = new StringBuilder();
        appendIfNotNull(
                builder, userInputScanner(), "User Input Scanner", Convert.Display::scanner);
        appendIfNotNull(builder, playerName(), "Player Name", Convert.Display::string);
        appendIfNotNull(builder, characterName(), "Character Name", Convert.Display::string);
        appendIfNotNull(
                builder, characterAncestry(), "Character Ancestry", Convert.Display::string);
        appendIfNotNull(builder, characterClass(), "Character Class", Convert.Display::string);
        appendIfNotNull(builder, level(), "Level", Convert.Display::obj);
        appendIfNotNull(builder, proficiency(), "Proficiency", Convert.Display::obj);
        appendIfNotNull(builder, hitPoints(), "Hit Points", Convert.Display::obj);
        appendIfNotNull(builder, armorClass(), "Armor Class", Convert.Display::obj);
        appendIfNotNull(builder, rollHp(), "Roll Hp", Convert.Display::obj);
        appendIfNotNull(builder, abilityScores(), "Ability Scores", Convert.Display::intArray);
        appendIfNotNull(
                builder, abilityModifiers(), "Ability Modifiers", Convert.Display::intArray);
        appendIfNotNull(builder, skillNames(), "Skill Names", Convert.Display::stringArray);
        appendIfNotNull(builder, skillModifiers(), "Skill Modifiers", Convert.Display::intArray);
        return builder.toString().trim();
    }

    private static <T> void appendIfNotNull(
            StringBuilder builder, T t, String label, Function<T, String> converter) {
        if (t != null) {
            builder.append(label).append(" = ").append(converter.apply(t)).append("\n");
        }
    }

    public static Project1Input decode(String s) {
        String[] args = Convert.Decode.args(s);
        return new Project1Input(
                Convert.Decode.scanner(args[0]),
                Convert.Decode.string(args[1]),
                Convert.Decode.string(args[2]),
                Convert.Decode.string(args[3]),
                Convert.Decode.string(args[4]),
                Convert.Decode.boxedInt(args[5]),
                Convert.Decode.boxedInt(args[6]),
                Convert.Decode.boxedInt(args[7]),
                Convert.Decode.boxedInt(args[8]),
                Convert.Decode.boxedBoolean(args[9]),
                Convert.Decode.intArray(args[10]),
                Convert.Decode.intArray(args[11]),
                Convert.Decode.stringArray(args[12]),
                Convert.Decode.intArray(args[13]),
                Convert.Decode.boxedLong(args[14]));
    }

    public static String encode(Project1Input a) {
        return Convert.Encode.args(
                new String[] {
                    Convert.Encode.scanner(a.userInputScanner()),
                    Convert.Encode.string(a.playerName()),
                    Convert.Encode.string(a.characterName()),
                    Convert.Encode.string(a.characterAncestry()),
                    Convert.Encode.string(a.characterClass()),
                    Convert.Encode.boxedInt(a.level()),
                    Convert.Encode.boxedInt(a.proficiency()),
                    Convert.Encode.boxedInt(a.hitPoints()),
                    Convert.Encode.boxedInt(a.armorClass()),
                    Convert.Encode.boxedBoolean(a.rollHp()),
                    Convert.Encode.intArray(a.abilityScores()),
                    Convert.Encode.intArray(a.abilityModifiers()),
                    Convert.Encode.stringArray(a.skillNames()),
                    Convert.Encode.intArray(a.skillModifiers()),
                    Convert.Encode.boxedLong(a.seed()),
                });
    }
}
