package projecttests.testing.input;

public interface ProjectInput {
    String display();

    String userInputScanner();

    Long seed();
}
