package projecttests.testing.input;

import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public final class Convert {
    public static final String LINE_DELIMITER = "$$$";
    public static final String ARG_DELIMITER = "|||";
    public static final String ARRAY_DELIMITER = ";;;";
    public static final String NULL_STRING = "";
    public static final String TRUE_STRING = "T";
    public static final String FALSE_STRING = "F";

    public static final class Encode {
        public static String lines(List<String> a) {
            return a.stream().collect(Collectors.joining(LINE_DELIMITER));
        }

        public static String args(String[] a) {
            return Arrays.asList(a).stream().collect(Collectors.joining(ARG_DELIMITER));
        }

        public static String scanner(String a) {
            return a == null ? NULL_STRING : a.replace("\n", LINE_DELIMITER);
        }

        public static String intArray(int[] a) {
            return a == null
                    ? NULL_STRING
                    : Arrays.stream(a)
                            .boxed()
                            .map(i -> i.toString())
                            .collect(Collectors.joining(ARRAY_DELIMITER));
        }

        public static String longArray(long[] a) {
            return a == null
                    ? NULL_STRING
                    : Arrays.stream(a)
                            .boxed()
                            .map(i -> i.toString())
                            .collect(Collectors.joining(ARRAY_DELIMITER));
        }

        public static String doubleArray(double[] a) {
            return a == null
                    ? NULL_STRING
                    : Arrays.stream(a)
                            .boxed()
                            .map(i -> i.toString())
                            .collect(Collectors.joining(ARRAY_DELIMITER));
        }

        public static String booleanArray(boolean[] a) {
            return a == null
                    ? NULL_STRING
                    : IntStream.range(0, a.length)
                            .mapToObj(i -> a[i] ? TRUE_STRING : FALSE_STRING)
                            .collect(Collectors.joining(ARRAY_DELIMITER));
        }

        public static String stringArray(String[] a) {
            return a == null
                    ? NULL_STRING
                    : Arrays.asList(a).stream().collect(Collectors.joining(ARRAY_DELIMITER));
        }

        public static String string(String a) {
            return a == null ? NULL_STRING : a;
        }

        public static String boxedInt(Integer a) {
            return a == null ? NULL_STRING : a.toString();
        }

        public static String boxedLong(Long a) {
            return a == null ? NULL_STRING : a.toString();
        }

        public static String boxedBoolean(Boolean a) {
            return a == null ? NULL_STRING : a.toString();
        }
    }

    public final class Decode {
        public static List<String> lines(String a) {
            return Arrays.asList(a.split(Pattern.quote(LINE_DELIMITER), -1));
        }

        public static String[] args(String a) {
            return a.split(Pattern.quote(ARG_DELIMITER), -1);
        }

        public static String scanner(String a) {
            return a.equals(NULL_STRING) ? null : a.replace(LINE_DELIMITER, "\n");
        }

        public static int[] intArray(String a) {
            return a.equals(NULL_STRING)
                    ? null
                    : Arrays.asList(a.split(Pattern.quote(ARRAY_DELIMITER), -1)).stream()
                            .mapToInt(Integer::parseInt)
                            .toArray();
        }

        public static long[] longArray(String a) {
            return a.equals(NULL_STRING)
                    ? null
                    : Arrays.asList(a.split(Pattern.quote(ARRAY_DELIMITER), -1)).stream()
                            .mapToLong(Long::parseLong)
                            .toArray();
        }

        public static double[] doubleArray(String a) {
            return a.equals(NULL_STRING)
                    ? null
                    : Arrays.asList(a.split(Pattern.quote(ARRAY_DELIMITER), -1)).stream()
                            .mapToDouble(Double::parseDouble)
                            .toArray();
        }

        public static boolean[] booleanArray(String a) {
            if (a.equals(NULL_STRING)) {
                return null;
            }
            String[] split = a.split(Pattern.quote(ARRAY_DELIMITER), -1);
            boolean[] result = new boolean[split.length];
            for (int i = 0; i < split.length; ++i) {
                result[i] = split[i].equals(TRUE_STRING);
            }
            return result;
        }

        public static String[] stringArray(String a) {
            return a.equals(NULL_STRING) ? null : a.split(Pattern.quote(ARRAY_DELIMITER), -1);
        }

        public static String string(String a) {
            return a.equals(NULL_STRING) ? null : a;
        }

        public static Integer boxedInt(String a) {
            return a.equals(NULL_STRING) ? null : Integer.parseInt(a);
        }

        public static Long boxedLong(String a) {
            return a.equals(NULL_STRING) ? null : Long.parseLong(a);
        }

        public static Boolean boxedBoolean(String a) {
            return a.equals(NULL_STRING) ? null : Boolean.parseBoolean(a);
        }
    }

    public final class Display {
        public static String scanner(String a) {
            return "Scanner(...)";
        }

        public static String intArray(int[] a) {
            return Arrays.stream(a)
                    .boxed()
                    .map(i -> i.toString())
                    .collect(Collectors.joining(", ", "{", "}"));
        }

        public static String longArray(long[] a) {
            return Arrays.stream(a)
                    .boxed()
                    .map(i -> i.toString())
                    .collect(Collectors.joining(", ", "{", "}"));
        }

        public static String doubleArray(double[] a) {
            return Arrays.stream(a)
                    .boxed()
                    .map(i -> i.toString())
                    .collect(Collectors.joining(", ", "{", "}"));
        }

        public static String booleanArray(boolean[] a) {
            return IntStream.range(0, a.length)
                    .mapToObj(i -> a[i] ? TRUE_STRING : FALSE_STRING)
                    .collect(Collectors.joining(", ", "{", "}"));
        }

        public static String stringArray(String[] a) {
            return Arrays.asList(a).stream()
                    .map(Convert.Display::string)
                    .collect(Collectors.joining(", ", "{", "}"));
        }

        public static String obj(Object a) {
            return a.toString();
        }

        public static String string(String s) {
            return "\"" + s + "\"";
        }
    }
}
