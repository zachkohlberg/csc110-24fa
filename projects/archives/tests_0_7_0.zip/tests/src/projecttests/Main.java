package projecttests;

import projecttests.commands.Commands;
import projecttests.logging.Logger;
import projecttests.util.Command;
import projecttests.util.CommandArgs;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

/** Launches the test program */
public class Main {
    public static final String COMMAND = "sh tests/test.sh";
    public static final String RECORD_FILENAME = "record.txt";
    public static final String VERSION = "0.7.0";

    private static Settings settings;

    // this is a kludge for the generate code
    public static void useDefaultSettings() {
        settings = getSettings(new ProgramArgs(new HashMap<>(), null, null));
    }

    public static Settings settings() {
        return settings;
    }

    public static void main(String[] args) {
        ProgramArgs programArgs = null;
        try {
            programArgs = parseArgs(args);

            settings = getSettings(programArgs);
        } catch (Throwable e) {
            e.printStackTrace(System.err);
            System.out.println("Printing main help message:");
            System.out.println(help());
            System.exit(1);
        }

        startLogger();
        Logger.info("Program version = " + Main.VERSION);

        int exitCode;
        try {
            programArgs.cmd().run(null, programArgs.cmdArgs());
            exitCode = 0;
        } catch (Throwable e) {
            Logger.error(e, "Encountered an error while running command: " + e.getMessage())
                    .print();
            exitCode = 1;
        }

        if (Logger.logging()) {
            Logger.stop();
        }
        System.exit(exitCode);
    }

    private static ProgramArgs parseArgs(String[] args) throws TestingException {
        List<String> argList = Arrays.asList(args);

        List<String> flagList = argList.stream().takeWhile(i -> i.startsWith("--")).toList();
        HashMap<String, String> flags = CommandArgs.parseFlags(flagList);

        if (flagList.size() == argList.size()) {
            throw new TestingException("No command provided!");
        }

        String cmdString = argList.get(flagList.size());
        Command<Main> cmd = Commands.getById(cmdString);
        if (cmd == null) {
            throw new TestingException(cmdString + " is not a valid command!");
        }

        CommandArgs cmdArgs = CommandArgs.parse(args, flagList.size() + 1);

        return new ProgramArgs(flags, cmd, cmdArgs);
    }

    private static Settings getSettings(ProgramArgs args) {
        Path binPath = Paths.get(args.flags().getOrDefault("bin-path", "tests/bin/program"));
        Path logPath = Paths.get(args.flags().getOrDefault("log-path", "tests/logs"));
        Path projectsPath = Paths.get(args.flags().getOrDefault("projects-path", "."));
        Path resPath = Paths.get(args.flags().getOrDefault("resource-path", "tests/res"));
        Path srcPath = Paths.get(args.flags().getOrDefault("src-path", "test/src"));
        Path studentPath = Paths.get(args.flags().getOrDefault("student-path", "tests/student"));

        return new Settings(binPath, logPath, projectsPath, resPath, srcPath, studentPath);
    }

    public static void startLogger() {
        try {
            Logger.start(settings().logPath());
        } catch (IOException e) {
            System.err.println(
                    """
ERROR: Failed to initialize logger!

This is likely a result of running this program from the wrong location. Make
sure you're in your projects folder, not the tests folder, and that you
extracted tests.zip correctly. The file tests/README.txt includes directions for
extracting tests.zip. If you fix both of these problems or confirm they aren't
present and this error still occurs, then ask for help.

The program will still run if possible, but no log will be recorded.

Below is a stack trace for the IOException that occurred when trying to
initialize the logger:
""");
            e.printStackTrace(System.err);
        }
    }

    public static String help() {
        return """
Tests and packages your projects.

Usage: {COMMAND} [OPTION]... COMMAND

Commands:
    test        Run tests for one or more projects
    status      Display the status of your projects
    pack        Package projects for submission on Blackboard
    help        Display help messages
    version     Display program's version number

See '{COMMAND} help COMMAND' for more information on a specific command.
See '{COMMAND} help --topic=topics' for a list of other help topics.
"""
                .replace("{COMMAND}", COMMAND);
    }

    public static String help(String topic) {
        switch (topic) {
            case "topic":
            case "topics":
                return """
Topics:
    options
    topics
""";
            case "option":
            case "options":
                return """
Options:
    --projects-path=<path>
        Search <path> for student projects instead of the working directory.
    --student-path=<path>
        Save student information to <path> instead of "tests/student".
    --log-path=<path>
        Save log files to <path> instead of "tests/logs".
    --resource-path=<path>
        Search for resource files in <path> instead of "tests/res".
    --src-path=<path>
        Search for this program's source code in <path> instead of "tests/src".
    --bin-path=<path>
        Search for compiled test program files in <path> instead of "tests/bin".
""";
            default:
                return "No help text for the topic " + topic;
        }
    }

    static record ProgramArgs(
            HashMap<String, String> flags, Command<Main> cmd, CommandArgs cmdArgs) {}

    public static record Settings(
            Path binPath,
            Path logPath,
            Path projectsPath,
            Path resPath,
            Path srcPath,
            Path studentPath) {
        public Path dataPath() {
            return resPath().resolve("data");
        }

        public Path jshPath() {
            return resPath().resolve("jsh");
        }

        public Path studentBackupsPath() {
            return studentPath().resolve("backups");
        }

        public Path studentBinPath() {
            return studentPath().resolve("bin");
        }

        public Path studentRecordsPath() {
            return studentPath().resolve("records");
        }

        public Path studentSrcPath() {
            return studentPath().resolve("src");
        }
    }
}
