package projecttests.util;

import java.util.Collection;

/** Superinterface for command and project. */
public interface HasId {
    String id();

    public static <T extends HasId> T getById(String id, Collection<T> c) {
        for (T hi : c) {
            if (hi.id().equalsIgnoreCase(id)) {
                return hi;
            }
        }
        return null;
    }
}
