package projecttests.util;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.Collection;
import java.util.stream.Collectors;

/** Helper methods for strings. */
public final class Strings {
    // no constructor
    private Strings() {}

    public static String header(String text, String suffix) {
        String border = "#".repeat(text.length() + 4);
        return border + "\n" + text + "\n" + border + suffix;
    }

    public static String getStackTrace(Throwable e) {
        try (StringWriter sw = new StringWriter();
                PrintWriter pw = new PrintWriter(sw)) {
            e.printStackTrace(pw);
            return sw.toString();
        } catch (IOException unexpectedException) {
            throw new RuntimeException(
                    "An IOException occurred when closing a string writer, but this should never"
                            + " happen. Something is wrong with the code!",
                    unexpectedException);
        }
    }

    public static String join(String... collection) {
        return join(Arrays.asList(collection));
    }

    public static String joinDelimited(String delimiter, String... collection) {
        return join(Arrays.asList(collection), delimiter);
    }

    public static String joinFull(
            String delimiter, String prefix, String suffix, String... collection) {
        return join(Arrays.asList(collection), delimiter, prefix, suffix);
    }

    public static <T extends CharSequence> String join(Collection<T> collection) {
        return collection.stream().collect(Collectors.joining());
    }

    public static <T extends CharSequence> String join(
            Collection<T> collection, CharSequence delimiter) {
        return collection.stream().collect(Collectors.joining(delimiter));
    }

    public static <T extends CharSequence> String join(
            Collection<T> collection,
            CharSequence delimiter,
            CharSequence prefix,
            CharSequence suffix) {
        return collection.stream().collect(Collectors.joining(delimiter, prefix, suffix));
    }
}
