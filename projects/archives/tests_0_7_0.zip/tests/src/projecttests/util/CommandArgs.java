package projecttests.util;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Stream;

public record CommandArgs(HashMap<String, String> flags, List<String> args)
        implements Iterable<String> {
    public String get(int i) {
        return args.get(i);
    }

    public int size() {
        return args.size();
    }

    public boolean optionSet(String option) {
        return flags.containsKey(option);
    }

    public String optionValue(String option) {
        return flags.get(option);
    }

    public Stream<String> stream() {
        return args.stream();
    }

    @Override
    public Iterator<String> iterator() {
        return args.iterator();
    }

    public static CommandArgs parse(String[] args, int skip) {
        List<String> argList =
                Arrays.asList(args).stream().skip(skip).filter(i -> !i.startsWith("--")).toList();

        List<String> flagList =
                Arrays.asList(args).stream().skip(skip).filter(i -> i.startsWith("--")).toList();
        HashMap<String, String> flags = parseFlags(flagList);

        return new CommandArgs(flags, argList);
    }

    public static HashMap<String, String> parseFlags(List<String> flagList) {
        HashMap<String, String> flags = new HashMap<>();

        for (String flag : flagList.stream().map(i -> i.substring(2)).toList()) {
            if (flag.contains("=")) {
                int index = flag.indexOf('=');
                String key = flag.substring(0, index);
                String value = flag.substring(index + 1);
                flags.put(key, value);
            } else {
                flags.put(flag, "");
            }
        }

        return flags;
    }
}
