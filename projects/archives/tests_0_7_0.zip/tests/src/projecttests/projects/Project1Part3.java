package projecttests.projects;

import projecttests.TestingException;
import projecttests.testing.JavaFunctionTest;
import projecttests.testing.Preprocessor;
import projecttests.testing.TestCase;
import projecttests.testing.TestResult;
import projecttests.testing.TestSettings;
import projecttests.testing.input.Project1Input;
import projecttests.util.Project;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.stream.IntStream;

/** Tests for project 1 part 3. */
public class Project1Part3 implements Project {
    @Override
    public String id() {
        return "1.3";
    }

    @Override
    public String programName() {
        return "CharacterSheet.java";
    }

    @Override
    public boolean compiles() {
        return true;
    }

    @Override
    public Path path() {
        return Paths.get("project1", "part3");
    }

    @Override
    public TestResult test(TestSettings settings) throws TestingException {
        Preprocessor preprocessor = new Preprocessor(this, List.of("System.exit"));
        preprocessor.run("student.project1.part3");

        ArrayList<TestCase> results = new ArrayList<>();

        int nextId = 1;
        JavaFunctionTest<Project1Input> test;

        test =
                new JavaFunctionTest<>(
                        this,
                        "apply-ancestry-adjustments",
                        nextId,
                        Project1Input::encode,
                        Project1Input::decode,
                        this::testApplyAncestryAdjustments);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "calculate-ability-modifiers",
                        nextId,
                        Project1Input::encode,
                        Project1Input::decode,
                        this::testCalculateAbilityModifiers);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "get-hit-die",
                        nextId,
                        Project1Input::encode,
                        Project1Input::decode,
                        this::testGetHitDie);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "roll-hit-points",
                        nextId,
                        Project1Input::encode,
                        Project1Input::decode,
                        this::testRollHitPoints);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "average-hit-points",
                        nextId,
                        Project1Input::encode,
                        Project1Input::decode,
                        this::testAverageHitPoints);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "calculate-armor-class",
                        nextId,
                        Project1Input::encode,
                        Project1Input::decode,
                        this::testCalculateArmorClass);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "get-skill-names",
                        nextId,
                        Project1Input::encode,
                        Project1Input::decode,
                        this::testGetSkillNames);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "calculate-skill-modifiers",
                        nextId,
                        Project1Input::encode,
                        Project1Input::decode,
                        this::testCalculateSkillModifiers);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "roll-ability-scores",
                        nextId,
                        Project1Input::encode,
                        Project1Input::decode,
                        this::testRollAbilityScores);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "purchase-ability-scores",
                        nextId,
                        Project1Input::encode,
                        Project1Input::decode,
                        this::testPurchaseAbilityScores);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "print-character",
                        nextId,
                        Project1Input::encode,
                        Project1Input::decode,
                        this::testPrintCharacter);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "create-character-sheet",
                        nextId,
                        Project1Input::encode,
                        Project1Input::decode,
                        this::testCreateCharacterSheet);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "run",
                        nextId,
                        Project1Input::encode,
                        Project1Input::decode,
                        this::testRun);
        results.addAll(test.run());

        return new TestResult(Collections.unmodifiableList(results), preprocessor.studentCode());
    }

    public List<String> testRun(Project1Input input) {
        student.project1.part3.Dice.setSeed(input.seed());
        student.project1.part3.CharacterSheet.run(new Scanner(input.userInputScanner()));
        return Collections.emptyList();
    }

    public List<String> testRollAbilityScores(Project1Input input) {
        student.project1.part3.Dice.setSeed(input.seed());
        int[] returnValue = student.project1.part3.CharacterSheet.rollAbilityScores();
        return IntStream.of(returnValue).boxed().map(i -> String.valueOf(i)).toList();
    }

    public List<String> testPurchaseAbilityScores(Project1Input input) {
        int[] returnValue =
                student.project1.part3.CharacterSheet.purchaseAbilityScores(
                        new Scanner(input.userInputScanner()));
        return IntStream.of(returnValue).boxed().map(i -> String.valueOf(i)).toList();
    }

    public List<String> testApplyAncestryAdjustments(Project1Input input) {
        student.project1.part3.CharacterSheet.applyAncestryAdjustments(
                input.characterAncestry(), input.abilityScores());
        return Collections.emptyList();
    }

    public List<String> testCalculateAbilityModifiers(Project1Input input) {
        int[] returnValue =
                student.project1.part3.CharacterSheet.calculateAbilityModifiers(
                        input.abilityScores());
        return IntStream.of(returnValue).boxed().map(i -> String.valueOf(i)).toList();
    }

    public List<String> testGetHitDie(Project1Input input) {
        int returnValue = student.project1.part3.CharacterSheet.getHitDie(input.characterClass());
        return List.of(String.valueOf(returnValue));
    }

    public List<String> testRollHitPoints(Project1Input input) {
        student.project1.part3.Dice.setSeed(input.seed());
        int returnValue =
                student.project1.part3.CharacterSheet.rollHitPoints(
                        input.characterClass(), input.level(), input.abilityModifiers());
        return List.of(String.valueOf(returnValue));
    }

    public List<String> testAverageHitPoints(Project1Input input) {
        int returnValue =
                student.project1.part3.CharacterSheet.averageHitPoints(
                        input.characterClass(), input.level(), input.abilityModifiers());
        return List.of(String.valueOf(returnValue));
    }

    public List<String> testCalculateArmorClass(Project1Input input) {
        int returnValue =
                student.project1.part3.CharacterSheet.calculateArmorClass(
                        input.characterClass(), input.abilityModifiers());
        return List.of(String.valueOf(returnValue));
    }

    public List<String> testGetSkillNames(Project1Input input) {
        String[] returnValue =
                student.project1.part3.CharacterSheet.getSkillNames(input.characterClass());
        return Arrays.asList(returnValue);
    }

    public List<String> testCalculateSkillModifiers(Project1Input input) {
        int[] returnValue =
                student.project1.part3.CharacterSheet.calculateSkillModifiers(
                        input.characterClass(), input.proficiency(), input.abilityModifiers());
        return IntStream.of(returnValue).boxed().map(i -> String.valueOf(i)).toList();
    }

    public List<String> testCreateCharacterSheet(Project1Input input) {
        student.project1.part3.CharacterSheet.createCharacterSheet(
                input.playerName(),
                input.characterName(),
                input.characterAncestry(),
                input.characterClass(),
                input.level(),
                input.rollHp(),
                input.abilityScores());
        return Collections.emptyList();
    }

    public List<String> testPrintCharacter(Project1Input input) {
        student.project1.part3.CharacterSheet.printCharacter(
                input.playerName(),
                input.characterName(),
                input.characterAncestry(),
                input.characterClass(),
                input.level(),
                input.proficiency(),
                input.hitPoints(),
                input.armorClass(),
                input.abilityScores(),
                input.abilityModifiers(),
                input.skillNames(),
                input.skillModifiers());
        return Collections.emptyList();
    }
}
