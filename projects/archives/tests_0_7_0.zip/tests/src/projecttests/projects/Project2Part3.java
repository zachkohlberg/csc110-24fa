package projecttests.projects;

import projecttests.TestingException;
import projecttests.testing.JavaFunctionTest;
import projecttests.testing.Preprocessor;
import projecttests.testing.TestCase;
import projecttests.testing.TestResult;
import projecttests.testing.TestSettings;
import projecttests.testing.input.Project2Input;
import projecttests.util.Project;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/** Tests for project 2 part 3. */
public class Project2Part3 implements Project {
    @Override
    public String id() {
        return "2.3";
    }

    @Override
    public String programName() {
        return "DiceGame.java";
    }

    @Override
    public boolean compiles() {
        return true;
    }

    @Override
    public Path path() {
        return Paths.get("project2", "part3");
    }

    @Override
    public TestResult test(TestSettings settings) throws TestingException {
        Preprocessor preprocessor = new Preprocessor(this, List.of("System.exit"));
        preprocessor.run("student.project2.part3");

        ArrayList<TestCase> results = new ArrayList<>();

        int nextId = 1;
        JavaFunctionTest<Project2Input> test;

        test =
                new JavaFunctionTest<>(
                        this,
                        "roll-all-dice",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testRollAllDice);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "roll-some-dice",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testRollSomeDice);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "dice-string",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testDiceString);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "count-dice",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testCountDice);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "upper-total",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testUpperTotal);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "upper-bonus",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testUpperBonus);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "lower-total",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testLowerTotal);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "total-score",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testTotalScore);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "calculate-upper-category",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testCalculateUpperCategory);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "calculate-three-of-a-kind",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testCalculateThreeOfAKind);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "calculate-four-of-a-kind",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testCalculateFourOfAKind);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "calculate-full-house",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testCalculateFullHouse);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "calculate-small-straight",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testCalculateSmallStraight);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "calculate-large-straight",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testCalculateLargeStraight);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "calculate-yahtzee",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testCalculateYahtzee);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "calculate-chance",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testCalculateChance);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "calculate-dice-score",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testCalculateDiceScore);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "score-string",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testScoreString);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "reroll-phase",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testRerollPhase);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "score-phase",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testScorePhase);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "game",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testGame);
        results.addAll(test.run());

        return new TestResult(Collections.unmodifiableList(results), preprocessor.studentCode());
    }

    public List<String> testGame(Project2Input input) {
        student.project2.Dice.setSeed(input.seed());
        student.project2.part3.DiceGame.game(new Scanner(input.userInputScanner()));
        return Collections.emptyList();
    }

    public List<String> testRerollPhase(Project2Input input) {
        student.project2.Dice.setSeed(input.seed());
        student.project2.part3.DiceGame.rerollPhase(
                new Scanner(input.userInputScanner()), input.diceArray());
        return Collections.emptyList();
    }

    public List<String> testScorePhase(Project2Input input) {
        student.project2.part3.DiceGame.scorePhase(
                new Scanner(input.userInputScanner()),
                input.diceArray(),
                input.scoresArray(),
                input.scoreCategoriesUsed(),
                input.scoreCategoryNames());
        return Collections.emptyList();
    }

    public List<String> testRollAllDice(Project2Input input) {
        student.project2.Dice.setSeed(input.seed());
        student.project2.part3.DiceGame.rollAllDice(input.diceArray());
        return Collections.emptyList();
    }

    public List<String> testRollSomeDice(Project2Input input) {
        student.project2.Dice.setSeed(input.seed());
        student.project2.part3.DiceGame.rollSomeDice(input.diceArray(), input.rerollLabels());
        return Collections.emptyList();
    }

    public List<String> testDiceString(Project2Input input) {
        String returnValue = student.project2.part3.DiceGame.diceString(input.diceArray());
        return Arrays.asList(returnValue.split("\n"));
    }

    public List<String> testScoreString(Project2Input input) {
        String returnValue =
                student.project2.part3.DiceGame.scoreString(
                        input.scoresArray(),
                        input.scoreCategoriesUsed(),
                        input.scoreCategoryNames(),
                        input.diceArray());
        return Arrays.asList(returnValue.split("\n"));
    }

    public List<String> testCountDice(Project2Input input) {
        return List.of(
                ""
                        + student.project2.part3.DiceGame.countDice(
                                input.diceArray(), input.dieValue()));
    }

    public List<String> testCalculateDiceScore(Project2Input input) {
        return List.of(
                ""
                        + student.project2.part3.DiceGame.calculateDiceScore(
                                input.diceArray(), input.scoreCategoryIndex()));
    }

    public List<String> testUpperTotal(Project2Input input) {
        return List.of("" + student.project2.part3.DiceGame.upperTotal(input.scoresArray()));
    }

    public List<String> testUpperBonus(Project2Input input) {
        return List.of("" + student.project2.part3.DiceGame.upperBonus(input.scoresArray()));
    }

    public List<String> testLowerTotal(Project2Input input) {
        return List.of("" + student.project2.part3.DiceGame.lowerTotal(input.scoresArray()));
    }

    public List<String> testTotalScore(Project2Input input) {
        return List.of("" + student.project2.part3.DiceGame.totalScore(input.scoresArray()));
    }

    public List<String> testCalculateUpperCategory(Project2Input input) {
        return List.of(
                ""
                        + student.project2.part3.DiceGame.calculateUpperCategory(
                                input.diceArray(), input.scoreCategoryIndex()));
    }

    public List<String> testCalculateThreeOfAKind(Project2Input input) {
        return List.of(
                "" + student.project2.part3.DiceGame.calculateThreeOfAKind(input.diceArray()));
    }

    public List<String> testCalculateFourOfAKind(Project2Input input) {
        return List.of(
                "" + student.project2.part3.DiceGame.calculateFourOfAKind(input.diceArray()));
    }

    public List<String> testCalculateFullHouse(Project2Input input) {
        return List.of("" + student.project2.part3.DiceGame.calculateFullHouse(input.diceArray()));
    }

    public List<String> testCalculateSmallStraight(Project2Input input) {
        return List.of(
                "" + student.project2.part3.DiceGame.calculateSmallStraight(input.diceArray()));
    }

    public List<String> testCalculateLargeStraight(Project2Input input) {
        return List.of(
                "" + student.project2.part3.DiceGame.calculateLargeStraight(input.diceArray()));
    }

    public List<String> testCalculateYahtzee(Project2Input input) {
        return List.of("" + student.project2.part3.DiceGame.calculateYahtzee(input.diceArray()));
    }

    public List<String> testCalculateChance(Project2Input input) {
        return List.of("" + student.project2.part3.DiceGame.calculateChance(input.diceArray()));
    }
}
