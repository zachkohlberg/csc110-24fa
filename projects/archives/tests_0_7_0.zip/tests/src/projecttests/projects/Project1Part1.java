package projecttests.projects;

import projecttests.TestingException;
import projecttests.testing.JshellIOTest;
import projecttests.testing.Preprocessor;
import projecttests.testing.TestResult;
import projecttests.testing.TestSettings;
import projecttests.util.Project;

import java.nio.file.Path;
import java.nio.file.Paths;

/** Tests for project 1 part 1. */
public class Project1Part1 implements Project {
    @Override
    public String id() {
        return "1.1";
    }

    @Override
    public String programName() {
        return "CharacterSheet1.jsh";
    }

    @Override
    public boolean compiles() {
        return false;
    }

    @Override
    public Path path() {
        return Paths.get("project1", "part1");
    }

    @Override
    public TestResult test(TestSettings settings) throws TestingException {
        Preprocessor preprocessor = new Preprocessor(this);
        preprocessor.run(null);
        JshellIOTest test = new JshellIOTest(this, settings);
        return test.run();
    }
}
