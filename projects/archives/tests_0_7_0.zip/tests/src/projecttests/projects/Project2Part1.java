package projecttests.projects;

import projecttests.TestingException;
import projecttests.testing.JavaFunctionTest;
import projecttests.testing.Preprocessor;
import projecttests.testing.TestCase;
import projecttests.testing.TestResult;
import projecttests.testing.TestSettings;
import projecttests.testing.input.Project2Input;
import projecttests.util.Project;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/** Tests for project 2 part 1. */
public class Project2Part1 implements Project {
    @Override
    public String id() {
        return "2.1";
    }

    @Override
    public String programName() {
        return "DiceGame.java";
    }

    @Override
    public boolean compiles() {
        return true;
    }

    @Override
    public Path path() {
        return Paths.get("project2", "part1");
    }

    @Override
    public TestResult test(TestSettings settings) throws TestingException {
        Preprocessor preprocessor = new Preprocessor(this, List.of("System.exit"));
        preprocessor.run("student.project2.part1");

        ArrayList<TestCase> results = new ArrayList<>();

        int nextId = 1;
        JavaFunctionTest<Project2Input> test;

        test =
                new JavaFunctionTest<>(
                        this,
                        "roll-all-dice",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testRollAllDice);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "roll-some-dice",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testRollSomeDice);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "dice-string",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testDiceString);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "game",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testGame);
        results.addAll(test.run());

        return new TestResult(Collections.unmodifiableList(results), preprocessor.studentCode());
    }

    public List<String> testGame(Project2Input input) {
        student.project2.Dice.setSeed(input.seed());
        student.project2.part1.DiceGame.game(new Scanner(input.userInputScanner()));
        return Collections.emptyList();
    }

    public List<String> testRollAllDice(Project2Input input) {
        student.project2.Dice.setSeed(input.seed());
        student.project2.part1.DiceGame.rollAllDice(input.diceArray());
        return Collections.emptyList();
    }

    public List<String> testRollSomeDice(Project2Input input) {
        student.project2.Dice.setSeed(input.seed());
        student.project2.part1.DiceGame.rollSomeDice(input.diceArray(), input.rerollLabels());
        return Collections.emptyList();
    }

    public List<String> testDiceString(Project2Input input) {
        String returnValue = student.project2.part1.DiceGame.diceString(input.diceArray());
        return Arrays.asList(returnValue.split("\n"));
    }
}
