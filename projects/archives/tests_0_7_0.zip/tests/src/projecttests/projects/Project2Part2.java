package projecttests.projects;

import projecttests.TestingException;
import projecttests.testing.JavaFunctionTest;
import projecttests.testing.Preprocessor;
import projecttests.testing.TestCase;
import projecttests.testing.TestResult;
import projecttests.testing.TestSettings;
import projecttests.testing.input.Project2Input;
import projecttests.util.Project;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/** Tests for project 2 part 2. */
public class Project2Part2 implements Project {
    @Override
    public String id() {
        return "2.2";
    }

    @Override
    public String programName() {
        return "DiceGame.java";
    }

    @Override
    public boolean compiles() {
        return true;
    }

    @Override
    public Path path() {
        return Paths.get("project2", "part2");
    }

    @Override
    public TestResult test(TestSettings settings) throws TestingException {
        Preprocessor preprocessor = new Preprocessor(this, List.of("System.exit"));
        preprocessor.run("student.project2.part2");

        ArrayList<TestCase> results = new ArrayList<>();

        int nextId = 1;
        JavaFunctionTest<Project2Input> test;

        test =
                new JavaFunctionTest<>(
                        this,
                        "roll-all-dice",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testRollAllDice);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "roll-some-dice",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testRollSomeDice);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "dice-string",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testDiceString);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "score-string",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testScoreString);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "count-dice",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testCountDice);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "calculate-dice-score",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testCalculateDiceScore);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "reroll-phase",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testRerollPhase);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "score-phase",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testScorePhase);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest<>(
                        this,
                        "game",
                        nextId,
                        Project2Input::encode,
                        Project2Input::decode,
                        this::testGame);
        results.addAll(test.run());

        return new TestResult(Collections.unmodifiableList(results), preprocessor.studentCode());
    }

    public List<String> testGame(Project2Input input) {
        student.project2.Dice.setSeed(input.seed());
        student.project2.part2.DiceGame.game(new Scanner(input.userInputScanner()));
        return Collections.emptyList();
    }

    public List<String> testRerollPhase(Project2Input input) {
        student.project2.Dice.setSeed(input.seed());
        student.project2.part2.DiceGame.rerollPhase(
                new Scanner(input.userInputScanner()), input.diceArray());
        return Collections.emptyList();
    }

    public List<String> testScorePhase(Project2Input input) {
        student.project2.part2.DiceGame.scorePhase(
                new Scanner(input.userInputScanner()), input.diceArray());
        return Collections.emptyList();
    }

    public List<String> testRollAllDice(Project2Input input) {
        student.project2.Dice.setSeed(input.seed());
        student.project2.part2.DiceGame.rollAllDice(input.diceArray());
        return Collections.emptyList();
    }

    public List<String> testRollSomeDice(Project2Input input) {
        student.project2.Dice.setSeed(input.seed());
        student.project2.part2.DiceGame.rollSomeDice(input.diceArray(), input.rerollLabels());
        return Collections.emptyList();
    }

    public List<String> testDiceString(Project2Input input) {
        String returnValue = student.project2.part2.DiceGame.diceString(input.diceArray());
        return Arrays.asList(returnValue.split("\n"));
    }

    public List<String> testScoreString(Project2Input input) {
        String returnValue = student.project2.part2.DiceGame.scoreString(input.diceArray());
        return Arrays.asList(returnValue.split("\n"));
    }

    public List<String> testCountDice(Project2Input input) {
        return List.of(
                ""
                        + student.project2.part2.DiceGame.countDice(
                                input.diceArray(), input.dieValue()));
    }

    public List<String> testCalculateDiceScore(Project2Input input) {
        return List.of(
                ""
                        + student.project2.part2.DiceGame.calculateDiceScore(
                                input.diceArray(), input.scoreCategoryIndex()));
    }
}
