package projecttests.commands;

import projecttests.*;
import projecttests.logging.Logger;
import projecttests.projects.Projects;
import projecttests.testing.TestResult;
import projecttests.testing.TestSettings;
import projecttests.testing.browser.ResultsBrowser;
import projecttests.util.Command;
import projecttests.util.CommandArgs;
import projecttests.util.FileIO;
import projecttests.util.Project;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/** Runs the tests for one or more projects. */
public class Test implements Command<Main> {
    @Override
    public void run(Main context, CommandArgs args) throws TestingException {
        Logger.info("test command");

        boolean skipResults = args.optionSet("skip-results");

        int timeout, maxThreads, retries;
        try {
            timeout =
                    Integer.parseInt(
                            args.flags().getOrDefault("timeout", TestSettings.DEFAULT_TIMEOUT));
            if (timeout < 1) {
                throw new TestingException("The timeout must be a positive integer.");
            }
        } catch (NumberFormatException e) {
            throw new TestingException("The timeout must be a positive integer.", e);
        }

        try {
            maxThreads =
                    Integer.parseInt(
                            args.flags()
                                    .getOrDefault("max-threads", TestSettings.DEFAULT_MAX_THREADS));
            if (maxThreads < 1) {
                throw new TestingException("The max-threads must be a positive integer.");
            }
        } catch (NumberFormatException e) {
            throw new TestingException("The max-threads must be a positive integer.", e);
        }

        try {
            retries =
                    Integer.parseInt(
                            args.flags().getOrDefault("retries", TestSettings.DEFAULT_RETRIES));
            if (retries < 0) {
                throw new TestingException("The retries must be a nonnegative integer.");
            }
        } catch (NumberFormatException e) {
            throw new TestingException("The retries must be a nonnegative integer.", e);
        }
        TestSettings settings = new TestSettings(maxThreads, timeout, retries);

        List<Project> projects = new ArrayList<>();
        if (args.size() == 0) {
            for (Project project : Projects.all()) {
                boolean testable = true;
                for (Path p : project.projectFilePaths()) {
                    if (FileIO.loadOrElse(p, null) == null) {
                        testable = false;
                    }
                }

                if (testable) {
                    List<String> passData = FileIO.loadOrElse(project.recordFilePath(), null);

                    if (passData == null
                            || passData.size() < 2
                            || !passData.get(0).equalsIgnoreCase("PASS")) {
                        projects.add(project);
                    }
                }
            }
        } else {
            for (String arg : args) {
                Project p = Projects.getById(arg);
                if (p == null) {
                    throw new TestingException(arg + " is not a valid project");
                }
                projects.add(p);
            }
        }

        Scanner in = new Scanner(System.in);
        for (Project p : projects) {
            TestResult result = p.test(settings);

            Logger.info("Saving overall result");

            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);

            try {
                Files.createDirectories(p.recordFilePath().getParent());
                Files.write(
                        p.recordFilePath(),
                        List.of(result.overallPass() ? "PASS" : "FAIL", timestamp),
                        StandardOpenOption.CREATE,
                        StandardOpenOption.TRUNCATE_EXISTING);
            } catch (IOException e) {
                Logger.error(e, "IOException while recording test result").print();
            }

            if (!skipResults) {
                ResultsBrowser browser = new ResultsBrowser(p, result);
                browser.run(in);
            }
        }
    }

    @Override
    public String id() {
        return "test";
    }

    @Override
    public String help() {
        return """
Tests a project or a group of projects.

USAGE: {COMMAND} test [PROJECT]... [OPTION]...

Valid project names: 1.1, 1.2, 1.3, 2.1, 2.2, 2.3

Examples:

{COMMAND} test
{COMMAND} test 1.2
{COMMAND} test 1.1 1.2 2.1 3.1
"""
                .replace("{COMMAND}", Main.COMMAND);
    }

    @Override
    public String help(String topic) {
        switch (topic) {
            case "topic":
            case "topics":
                return """
Topics:
    options
    topics
""";
            case "option":
            case "options":
                return """
Options:
    --skip-results
        Don't show the results browser after the test is finished. This will
        still record whether the test passed or failed for the status and pack
        commands.
    --max-threads=<n>
        Limit the number of threads for Jshell tests to <n>. This is the number
        of test cases that the program will attempt to run concurrently, and it
        defaults to {DEFAULT_MAX_THREADS}. Lowering the number may help if tests repeatedly crash
        or timeout.
    --timeout=<n>
        Allow tests to run for up to <n> seconds before ending the test with a
        timeout error. This defaults to {DEFAULT_TIMEOUT}, and if your computer takes too long
        to run the tests then you may want to raise this number. A timeout is
        necessary to handle errors that cause your code to run indefinitely,
        such as infinite loops.
    --retries=<n>
        Automatically retries Jshell test cases that did not complete up to <n>
        times, and it defaults to {DEFAULT_RETRIES}. This will not retry tests that failed due
        to incorrect output. It only applies to test cases that timed out or
        encountered an unexpected error that may not be related to your program
        (such test cases are marked as incomplete in the results summary.
"""
                        .replace("{DEFAULT_MAX_THREADS}", TestSettings.DEFAULT_MAX_THREADS)
                        .replace("{DEFAULT_TIMEOUT}", TestSettings.DEFAULT_TIMEOUT)
                        .replace("{DEFAULT_RETRIES}", TestSettings.DEFAULT_RETRIES);
            default:
                return Command.super.help(topic);
        }
    }
}
