package projecttests.commands;

import projecttests.*;
import projecttests.logging.Logger;
import projecttests.projects.Projects;
import projecttests.util.Command;
import projecttests.util.CommandArgs;
import projecttests.util.FileIO;
import projecttests.util.Project;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

/** Packages one or more projects for submission. */
public class Pack implements Command<Main> {
    @Override
    public void run(Main context, CommandArgs args) throws TestingException {
        if (args.size() != 0) {
            throw new TestingException(id() + " expects zero arguments");
        }

        Logger.info("pack command");

        boolean includeNopass = args.optionSet("include-nopass");

        List<Project> guided =
                Projects.guided().stream().filter(i -> check(i, includeNopass)).toList();
        List<Project> expanded =
                Projects.expanded().stream().filter(i -> check(i, includeNopass)).toList();

        if (guided.isEmpty() && expanded.isEmpty()) {
            Logger.info("No projects included, did not create zip.").print();
            return;
        }

        Logger.info("Zipping guided project files.");
        if (!guided.isEmpty()) {
            Path guidedZipPath =
                    Main.settings().projectsPath().resolve("guided_project_submission.zip");
            List<Path> guidedContents =
                    guided.stream()
                            .flatMap(p -> p.projectFilePaths().stream().map(i -> i.normalize()))
                            .toList();
            try {
                FileIO.zip(guidedZipPath, guidedContents);
            } catch (IOException e) {
                throw new TestingException(
                        "IOException while trying to zip project files: " + e.getMessage(), e);
            }
        }

        Logger.info("Zipping expanded project files.");
        for (Project ep : expanded) {
            Path expandedZipPath =
                    Main.settings()
                            .projectsPath()
                            .resolve(
                                    "expanded_project_"
                                            + ep.id().replace(".", "_")
                                            + "_submission.zip");
            List<Path> expandedContents =
                    ep.projectFilePaths().stream().map(i -> i.normalize()).toList();
            try {
                FileIO.zip(expandedZipPath, expandedContents);
            } catch (IOException e) {
                throw new TestingException(
                        "IOException while trying to zip project files: " + e.getMessage(), e);
            }
        }
    }

    boolean check(Project project, boolean includeNopass) {
        Logger.info("Checking project " + project.id()).print();
        String name = "Project " + project.id();

        if (!project.checkProjectFiles()) {
            Logger.info(
                            name
                                    + " will be skipped because it is missing files or a file is"
                                    + " named incorrectly.")
                    .print();
            return false;
        } else {
            Logger.info(name + "'s files were located successfully.").print();
        }

        List<String> passData = FileIO.loadOrElse(project.recordFilePath(), null);
        if (passData == null || passData.size() == 0 || !passData.get(0).equals("PASS")) {
            if (includeNopass) {
                Logger.info(
                                "WARNING: "
                                        + name
                                        + " hasn't passed its tests, but you've chosen to include"
                                        + " nonpassing projects.")
                        .print();
            } else {
                Logger.info(
                                name
                                        + " will be skipped because it hasn't passed its tests. You"
                                        + " can include it anyway by rerunning this command with"
                                        + " the --include-nopass flag.")
                        .print();
                return false;
            }
        } else {
            Logger.info(name + " appears to have passed its tests.");
        }

        Logger.info(name + " will be included in the zip.").print();

        return true;
    }

    @Override
    public String id() {
        return "pack";
    }

    @Override
    public String help() {
        return """
Packages all projects that have previously passed their tests for upload to
Blackboard.

USAGE: {COMMAND} pack [OPTION]...
"""
                .replace("{COMMAND}", Main.COMMAND);
    }

    @Override
    public String help(String topic) {
        switch (topic) {
            case "topic":
            case "topics":
                return """
Topics:
    options
    topics
""";
            case "option":
            case "options":
                return """
Options:
    --include-nopass
        Include projects that haven't passed their tests.
""";
            default:
                return Command.super.help(topic);
        }
    }
}
