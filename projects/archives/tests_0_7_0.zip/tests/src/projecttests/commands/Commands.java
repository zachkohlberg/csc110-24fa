package projecttests.commands;

import projecttests.Main;
import projecttests.util.Command;
import projecttests.util.HasId;

import java.util.List;

/** Contains helper methods for program commands. */
public class Commands {
    static List<Command<Main>> all =
            List.of(new Test(), new Help(), new Status(), new Pack(), new Version());

    public static List<Command<Main>> all() {
        return all;
    }

    public static Command<Main> getById(String id) {
        return HasId.getById(id, all);
    }

    public static boolean isCommand(String id) {
        return getById(id) != null;
    }
}
