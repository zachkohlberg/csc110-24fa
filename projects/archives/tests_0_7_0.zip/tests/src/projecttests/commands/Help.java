package projecttests.commands;

import projecttests.*;
import projecttests.util.Command;
import projecttests.util.CommandArgs;

/** Displays help message for the program or a specific command. */
public class Help implements Command<Main> {
    @Override
    public void run(Main context, CommandArgs args) throws TestingException {
        String topic = args.flags().getOrDefault("topic", null);

        if (args.size() == 1) {
            Command<Main> c = Commands.getById(args.get(0));
            if (c == null) {
                throw new TestingException(args.get(0) + " isn't a command");
            }

            System.out.println(topic == null ? c.help() : c.help(topic));
        } else {
            System.out.println(topic == null ? Main.help() : Main.help(topic));
        }
    }

    @Override
    public String id() {
        return "help";
    }

    @Override
    public String help() {
        return """
Displays a help message for the program, a command, or a topic.

USAGE:  {COMMAND} help [--topic=TOPIC]
        {COMMAND} help COMMAND [--topic=TOPIC]

Examples:

{COMMAND} help
{COMMAND} help --topic=options
{COMMAND} help test
{COMMAND} help test --topic=options
"""
                .replace("{COMMAND}", Main.COMMAND);
    }

    @Override
    public String help(String topic) {
        switch (topic) {
            case "topic":
            case "topics":
                return """
Topics:
    options
    topics
""";
            case "option":
            case "options":
                return """
Options:
    --topic=<t>
        Display help text for the topic t in the context of the program or a
        specific command.
""";
            default:
                return Command.super.help(topic);
        }
    }
}
