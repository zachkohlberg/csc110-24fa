package student.project1.part3;

/** Local copy for 1.3. */
public final class Dice extends student.project2.Dice {}
