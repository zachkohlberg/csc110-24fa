package student.project1.part3;

/** Placeholder for 1.3 so other test code can compile. */
public class CharacterSheet {
    public static void run(java.util.Scanner input) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static int[] rollAbilityScores() {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static int[] purchaseAbilityScores(java.util.Scanner input) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static void applyAncestryAdjustments(String a, int[] b) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static int[] calculateAbilityModifiers(int[] a) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static int getHitDie(String a) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static int rollHitPoints(String a, int b, int[] c) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static int averageHitPoints(String a, int b, int[] c) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static int calculateArmorClass(String a, int[] b) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static String[] getSkillNames(String a) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static int[] calculateSkillModifiers(String a, int b, int[] c) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static void createCharacterSheet(
            String a, String b, String c, String d, int e, boolean f, int[] g) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static void printCharacter(
            String a,
            String b,
            String c,
            String d,
            int e,
            int f,
            int g,
            int h,
            int[] i,
            int[] j,
            String[] k,
            int[] l) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }
}
