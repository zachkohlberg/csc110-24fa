package student.project1.part1;

/**
 * Placeholder for 1.1 so other test code can compile.
 */
public class CharacterSheet {
    public static void run(java.util.Scanner input) {}
}
