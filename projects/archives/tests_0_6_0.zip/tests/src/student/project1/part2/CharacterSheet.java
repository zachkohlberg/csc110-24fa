package student.project1.part2;

/**
 * Placeholder for 1.2 so other test code can compile.
 */
public class CharacterSheet {
    public static void run(java.util.Scanner input) {}
}
