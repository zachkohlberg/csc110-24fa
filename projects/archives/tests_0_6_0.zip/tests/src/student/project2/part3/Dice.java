package student.project2.part3;

/** Local copy for 2.3. */
public final class Dice extends student.project2.Dice {}
