package student.project2.part1;

/** Local copy for 2.1. */
public final class Dice extends student.project2.Dice {}
