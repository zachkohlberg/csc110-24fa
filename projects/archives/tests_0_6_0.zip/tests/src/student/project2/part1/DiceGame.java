package student.project2.part1;

/** Placeholder for 2.1 so other test code can compile. */
public class DiceGame {
    // Require Dice.java to compile
    private Dice __;

    public static void game(java.util.Scanner a) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static void rollAllDice(int[] a) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static void rollSomeDice(int[] a, String b) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }

    public static String diceString(int[] a) {
        throw new UnsupportedOperationException("Placeholder code contains no implementation!");
    }
}
