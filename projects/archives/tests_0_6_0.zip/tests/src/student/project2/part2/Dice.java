package student.project2.part2;

/** Local copy for 2.2. */
public final class Dice extends student.project2.Dice {}
