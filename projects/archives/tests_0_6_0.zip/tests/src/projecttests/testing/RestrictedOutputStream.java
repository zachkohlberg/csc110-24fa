package projecttests.testing;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class RestrictedOutputStream extends OutputStream {
    private ByteArrayOutputStream out;
    private int sizeLimit;

    public RestrictedOutputStream(ByteArrayOutputStream out, int sizeLimit) {
        this.out = out;
        this.sizeLimit = sizeLimit;
    }

    @Override
    public void write(byte[] b) throws IOException {
        if (out.size() + b.length > sizeLimit) {
            throw new IOException("Output buffer size limit exceeded!");
        }
        out.write(b);
    }

    @Override
    public void write(byte[] b, int off, int len) throws IOException {
        if (out.size() + len > sizeLimit) {
            throw new IOException("Output buffer size limit exceeded!");
        }
        out.write(b, off, len);
    }

    @Override
    public void write(int b) throws IOException {
        if (out.size() + 1 > sizeLimit) {
            throw new IOException("Output buffer size limit exceeded!");
        }
        out.write(b);
    }
}
