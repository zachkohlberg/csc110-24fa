package projecttests.testing.browser.commands;

import projecttests.testing.browser.ResultsBrowser;
import projecttests.util.Command;
import projecttests.util.HasId;

/** Contains helper methods for program commands. */
public class Commands {
    static java.util.List<Command<ResultsBrowser>> all =
            java.util.List.of(
                    new Summary(), new Code(), new Show(), new Help(), new List(), new Quit());

    public static java.util.List<Command<ResultsBrowser>> all() {
        return all;
    }

    public static Command<ResultsBrowser> getById(String id) {
        return HasId.getById(id, all);
    }

    public static boolean isCommand(String id) {
        return getById(id) != null;
    }
}
