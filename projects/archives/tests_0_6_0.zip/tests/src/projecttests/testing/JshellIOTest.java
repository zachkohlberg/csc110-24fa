package projecttests.testing;

import jdk.jshell.tool.JavaShellToolBuilder;

import projecttests.*;
import projecttests.logging.Logger;
import projecttests.util.FileIO;
import projecttests.util.Project;
import projecttests.util.Strings;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.IntStream;

/** Tests a Jshell program's I/O with multiple test cases. */
public class JshellIOTest {
    private Project project;
    private Path programPath, inputPath, expectedOutputPath, testSetupJshPath, quitJshPath;

    public JshellIOTest(Project project) {
        this.project = project;
        this.programPath = Main.settings().studentSrcPath().resolve(project.programRelativeFilePath());
        this.inputPath =
                Main.settings().dataPath().resolve(project.path()).resolve("jshell_input.txt");
        this.expectedOutputPath =
                Main.settings()
                        .dataPath()
                        .resolve(project.path())
                        .resolve("jshell_expected_output.txt");
        this.testSetupJshPath = Main.settings().jshPath().resolve("JshellTestSetup.jsh");
        this.quitJshPath = Main.settings().jshPath().resolve("Quit.jsh");
    }

    public TestResult run() throws TestingException {
        List<String>
                cleanStudentCode =
                        FileIO.loadOrElseThrow(
                                programPath, () -> new TestingException("Failed to load file!")),
                input =
                        FileIO.loadOrElseThrow(
                                inputPath, () -> new TestingException("Failed to load file!")),
                expectedOutput =
                        FileIO.loadOrElseThrow(
                                expectedOutputPath,
                                () -> new TestingException("Failed to load file!"));

        List<TestCase> testCases = createTestCases(input, expectedOutput);

        Instant runStartTime = Instant.now();

        testCases = runTestCases(testCases);

        Instant runEndTime = Instant.now();
        long runDuration = runStartTime.until(runEndTime, ChronoUnit.MILLIS);
        Logger.infoFormat(
                        "Tests finished after %d.%03d seconds.",
                        runDuration / 1000, runDuration % 1000)
                .print();

        TestResult result = new TestResult(testCases, cleanStudentCode);

        for (int i = 0; i < Main.settings().retries(); ++i) {
            if (result.incomplete() > 0) {
                result = rerunIncompleteTests(result);
            } else {
                break;
            }
        }

        return result;
    }

    public TestResult rerunIncompleteTests(TestResult result) throws TestingException {
        List<TestCase> rerun =
                result.results().stream().filter(i -> i.outcome() == Outcome.Incomplete).toList();

        Logger.info("Rerunning " + rerun.size() + " incomplete test cases.").print();

        Instant runStartTime = Instant.now();

        rerun = runTestCases(rerun);

        Instant runEndTime = Instant.now();
        long runDuration = runStartTime.until(runEndTime, ChronoUnit.MILLIS);
        Logger.infoFormat(
                        "Rerun finished after %d.%03d seconds.",
                        runDuration / 1000, runDuration % 1000)
                .print();

        return result.withUpdatedTestCases(rerun);
    }

    public List<TestCase> createTestCases(List<String> input, List<String> expectedOutput) {
        ArrayList<TestCase> testCases = new ArrayList<>();
        for (int i = 0; i < input.size(); ++i) {
            testCases.add(
                    new TestCase(
                            "jsh",
                            i + 1,
                            Arrays.asList(input.get(i).split("\\|")),
                            OutputLine.uncheckedList(
                                    Arrays.asList(expectedOutput.get(i).split("\\|"))),
                            Collections.emptyList(),
                            Collections.emptyList(),
                            Collections.emptyList(),
                            Outcome.Incomplete,
                            TestCase.Result.empty()));
        }
        return Collections.unmodifiableList(testCases);
    }

    public List<TestCase> runTestCases(List<TestCase> testCases) throws TestingException {
        ExecutorService threadPool = Executors.newFixedThreadPool(Main.settings().maxThreads());

        System.out.println("Running " + testCases.size() + " Jshell IO tests. Progress:");
        System.out.println("_".repeat(testCases.size()));
        List<Future<TestCase.Result>> futures;
        try {
            // invokeAll returns futures collection in same order as tasks
            futures =
                    threadPool.invokeAll(
                            testCases.stream().map(tc -> new Task(tc)).toList(),
                            Main.settings().timeout(),
                            TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            // shouldn't happen because we aren't interrupting the thread, but
            // we can't completely ignore this because we need to initialize
            // futures
            throw new TestingException("Testing interrupted!", e);
        }

        threadPool.close();

        System.out.println();

        List<TestCase> finishedTestCases =
                IntStream.range(0, testCases.size())
                        .mapToObj(i -> processFutureResult(testCases.get(i), futures.get(i)))
                        .toList();

        return finishedTestCases;
    }

    public TestCase processFutureResult(TestCase incomplete, Future<TestCase.Result> result) {
        switch (result.state()) {
            case FAILED:
                return incomplete.incomplete(
                        List.of(Strings.getStackTrace(result.exceptionNow())),
                        Collections.emptyList());
            case SUCCESS:
                return evaluateTestCase(incomplete, result.resultNow());
            default:
                return incomplete.incomplete(Collections.emptyList(), Collections.emptyList());
        }
    }

    public TestCase evaluateTestCase(TestCase incomplete, TestCase.Result result) {
        ArrayList<OutputLine> studentOutput = new ArrayList<>(), expectedOutput = new ArrayList<>();
        TestCase.checkOutput(
                result.studentOutput(),
                incomplete.expectedOutput(),
                studentOutput,
                expectedOutput,
                LineStatus.NO_MATCH,
                LineStatus.ERROR);
        return new TestCase(
                incomplete.label(),
                incomplete.id(),
                incomplete.programInput(),
                Collections.unmodifiableList(expectedOutput),
                incomplete.paramsBefore(),
                incomplete.expectedParamsAfter(),
                incomplete.expectedReturnValue(),
                OutputLine.allOkay(List.of(expectedOutput, studentOutput))
                        ? Outcome.Pass
                        : Outcome.Fail,
                new TestCase.Result(
                        Collections.unmodifiableList(studentOutput),
                        result.studentParamsAfter(),
                        result.studentReturnValue(),
                        result.errors(),
                        result.feedback()));
    }

    public List<String> generateOutput() throws TestingException {
        // TODO: update this
        /*
        List<String> studentCode = loadResource(project.programFilePath()),
                input = loadResource(inputPath);

        studentCode = cleanProgram(studentCode);

        createModifiedProgram(studentCode, modifiedStudentCodePath);

        ExecutorService threadPool = Executors.newFixedThreadPool(Main.settings().maxThreads());
        ArrayList<Task> tasks = new ArrayList<Task>();
        for (int i = 0; i < input.size(); ++i) {
            tasks.add(new Task("jsh", i + 1, input.get(i), ""));
        }
        System.out.println("Running " + input.size() + " Jshell IO tests. Progress:");
        System.out.println("_".repeat(input.size()));

        List<Future<TestCase>> futures;
        try {
            futures = threadPool.invokeAll(tasks, Main.settings().timeout(), TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            throw new TestingException("Testing interrupted!", e);
        }

        System.out.println();
        System.out.println("Finished generating test output.");

        List<TestCase> results =
                futures.stream()
                        .filter(i -> i.state() == Future.State.SUCCESS)
                        .map(Future::resultNow)
                        .toList();
        results.stream().forEach(i -> Logger.info("Test Case:\n%s", i.fullInfo()));

        List<String> studentOutput =
                results.stream()
                        .sorted(
                                new Comparator<TestCase>() {
                                    public int compare(TestCase r1, TestCase r2) {
                                        return r1.id() - r2.id();
                                    }
                                })
                        .map(
                                i ->
                                        i.studentOutput().stream()
                                                .map(j -> j.line())
                                                .filter(j -> !j.startsWith("##"))
                                                .collect(Collectors.joining("|")))
                        .toList();

        threadPool.close();

        return studentOutput;
        */
        return null;
    }

    class Task implements Callable<TestCase.Result> {
        private TestCase testCase;
        private List<String> output, errors;

        public Task(TestCase testCase) {
            this.testCase = testCase;
        }

        @Override
        public TestCase.Result call() throws Exception {
            runJshell();
            System.out.print("#");
            return TestCase.Result.unchecked(
                    output,
                    Collections.emptyList(),
                    Collections.emptyList(),
                    errors,
                    Collections.emptyList());
        }

        void runJshell() throws Exception {
            try (ByteArrayOutputStream bufferIgnore = new ByteArrayOutputStream();
                    ByteArrayOutputStream bufferOut = new ByteArrayOutputStream();
                    ByteArrayOutputStream bufferErr = new ByteArrayOutputStream();
                    ByteArrayInputStream cmdIn = new ByteArrayInputStream(new byte[0]);
                    ByteArrayInputStream userIn =
                            new ByteArrayInputStream(
                                    Strings.join(testCase.programInput(), "\n").getBytes());
                    PrintStream printIgnore = new PrintStream(bufferIgnore);
                    PrintStream printOut = new PrintStream(bufferOut);
                    PrintStream printErr = new PrintStream(bufferErr)) {
                JavaShellToolBuilder.builder()
                        .in(cmdIn, userIn)
                        .out(printIgnore, printIgnore, printOut)
                        .err(printErr)
                        .run(
                                testSetupJshPath.toString(),
                                programPath.toString(),
                                quitJshPath.toString());

                output = Processing.cleanOutput(Arrays.asList(bufferOut.toString().split("\n")));
                errors =
                        Arrays.asList(bufferErr.toString().split("\n")).stream()
                                .filter(i -> i != null && !i.isBlank())
                                .toList();
            }
        }
    }
}
