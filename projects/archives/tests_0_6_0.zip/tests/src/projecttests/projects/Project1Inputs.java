package projecttests.projects;

/** Functions that generate random sample inputs for project 1. */
public class Project1Inputs {
    public static String randomBeefAndDairyActor() {
        String[] names =
                new String[] {
                    "Benjamin Partridge",
                    "Mike Wozniak",
                    "Nadia Kamil",
                    "Mike Bubbins",
                    "Jack Bernhardt",
                    "Gareth Gwynn",
                    "Sian Harries",
                    "Henry Paker",
                };
        return names[(int) (Math.random() * names.length)];
    }

    public static String randomBeefAndDairyCharacter() {
        String[] names =
                new String[] {
                    "Gareth Belge",
                    "Dr. David Pin",
                    "Eli Roberts",
                    "Paula Redside",
                    "Lesley Peters",
                    "Doug Bloch",
                    "Roosevelt Macintosh",
                    "Cynthia Pickton",
                    "Airon Ball",
                    "Steve Kanathon",
                    "Bob Trescothick",
                    "Dr. Sam Archer",
                    "Michael Banyan",
                    "Philip Mushroom",
                    "Les Cheese",
                    "Sid Onion",
                    "Glenjamin",
                    "Svenjamin",
                    "Lester Crabtree",
                    "Dustin France",
                    "Paul Paul",
                };
        return names[(int) (Math.random() * names.length)];
    }

    public static int randomAbilityScore() {
        return 8 + (int) (Math.random() * 8);
    }

    public static int randomLevel() {
        return 1 + (int) (Math.random() * 20);
    }

    public static String randomAncestry() {
        String[] options =
                new String[] {
                    "human", "elf", "dwarf",
                };
        return options[(int) (Math.random() * options.length)];
    }

    public static String randomClass() {
        String[] options =
                new String[] {
                    "fighter", "rogue", "ranger",
                };
        return options[(int) (Math.random() * options.length)];
    }
}
