package projecttests.projects;

import projecttests.TestingException;
import projecttests.testing.JavaFunctionTest;
import projecttests.testing.Preprocessor;
import projecttests.testing.TestCase;
import projecttests.testing.TestResult;
import projecttests.testing.input.Project2Input;
import projecttests.testing.input.generators.Project2;
import projecttests.util.Project;

import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/** Tests for project 2 part 3. */
public class Project2Part3 implements Project {
    @Override
    public String id() {
        return "2.3";
    }

    @Override
    public String programName() {
        return "DiceGame.java";
    }

    @Override
    public boolean compiles() {
        return true;
    }

    @Override
    public Path path() {
        return FileSystems.getDefault().getPath("project2", "part3");
    }

    @Override
    public TestResult test() throws TestingException {
        Preprocessor preprocessor = new Preprocessor(this, List.of("System.exit"));
        preprocessor.run("student.project2.part3");

        ArrayList<TestCase> results = new ArrayList<>();

        int nextId = 1;
        JavaFunctionTest test;

        test = new JavaFunctionTest(this, "roll-all-dice", nextId, this::testRollAllDice);
        results.addAll(test.run());

        nextId = test.nextId();
        test = new JavaFunctionTest(this, "roll-some-dice", nextId, this::testRollSomeDice);
        results.addAll(test.run());

        nextId = test.nextId();
        test = new JavaFunctionTest(this, "dice-string", nextId, this::testDiceString);
        results.addAll(test.run());

        nextId = test.nextId();
        test = new JavaFunctionTest(this, "count-dice", nextId, this::testCountDice);
        results.addAll(test.run());

        nextId = test.nextId();
        test = new JavaFunctionTest(this, "upper-total", nextId, this::testUpperTotal);
        results.addAll(test.run());

        nextId = test.nextId();
        test = new JavaFunctionTest(this, "upper-bonus", nextId, this::testUpperBonus);
        results.addAll(test.run());

        nextId = test.nextId();
        test = new JavaFunctionTest(this, "lower-total", nextId, this::testLowerTotal);
        results.addAll(test.run());

        nextId = test.nextId();
        test = new JavaFunctionTest(this, "total-score", nextId, this::testTotalScore);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest(
                        this, "calculate-upper-category", nextId, this::testCalculateUpperCategory);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest(
                        this, "calculate-three-of-a-kind", nextId, this::testCalculateThreeOfAKind);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest(
                        this, "calculate-four-of-a-kind", nextId, this::testCalculateFourOfAKind);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest(
                        this, "calculate-full-house", nextId, this::testCalculateFullHouse);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest(
                        this, "calculate-small-straight", nextId, this::testCalculateSmallStraight);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest(
                        this, "calculate-large-straight", nextId, this::testCalculateLargeStraight);
        results.addAll(test.run());

        nextId = test.nextId();
        test = new JavaFunctionTest(this, "calculate-yahtzee", nextId, this::testCalculateYahtzee);
        results.addAll(test.run());

        nextId = test.nextId();
        test = new JavaFunctionTest(this, "calculate-chance", nextId, this::testCalculateChance);
        results.addAll(test.run());

        nextId = test.nextId();
        test =
                new JavaFunctionTest(
                        this, "calculate-dice-score", nextId, this::testCalculateDiceScore);
        results.addAll(test.run());

        nextId = test.nextId();
        test = new JavaFunctionTest(this, "score-string", nextId, this::testScoreString);
        results.addAll(test.run());

        nextId = test.nextId();
        test = new JavaFunctionTest(this, "reroll-phase", nextId, this::testRerollPhase);
        results.addAll(test.run());

        nextId = test.nextId();
        test = new JavaFunctionTest(this, "score-phase", nextId, this::testScorePhase);
        results.addAll(test.run());

        nextId = test.nextId();
        test = new JavaFunctionTest(this, "game", nextId, this::testGame);
        results.addAll(test.run());

        return new TestResult(Collections.unmodifiableList(results), preprocessor.studentCode());
    }

    @Override
    public void generateIO() throws TestingException {
        Preprocessor preprocessor = new Preprocessor(this);
        preprocessor.run("student.project2.part3");

        JavaFunctionTest test;

        test = new JavaFunctionTest(this, "roll-all-dice", 1, this::testRollAllDice);
        test.generateData(Project2.generate(Project2.Part3::rollAllDice, 20));

        test = new JavaFunctionTest(this, "roll-some-dice", 1, this::testRollSomeDice);
        test.generateData(Project2.generate(Project2.Part3::rollSomeDice, 40));

        test = new JavaFunctionTest(this, "dice-string", 1, this::testDiceString);
        test.generateData(Project2.generate(Project2.Part3::diceString, 40));

        test = new JavaFunctionTest(this, "score-string", 1, this::testScoreString);
        test.generateData(Project2.generate(Project2.Part3::scoreString, 40));

        test = new JavaFunctionTest(this, "count-dice", 1, this::testCountDice);
        test.generateData(Project2.generate(Project2.Part3::countDice, 40));

        test = new JavaFunctionTest(this, "calculate-dice-score", 1, this::testCalculateDiceScore);
        test.generateData(Project2.generate(Project2.Part3::calculateDiceScore, 40));

        test = new JavaFunctionTest(this, "reroll-phase", 1, this::testRerollPhase);
        test.generateData(Project2.generate(Project2.Part3::rerollPhase, 20));

        test = new JavaFunctionTest(this, "score-phase", 1, this::testScorePhase);
        test.generateData(Project2.generate(Project2.Part3::scorePhase, 20));

        test = new JavaFunctionTest(this, "game", 1, this::testGame);
        test.generateData(Project2.generate(Project2.Part3::game, 10));

        test = new JavaFunctionTest(this, "upper-total", 1, this::testUpperTotal);
        test.generateData(Project2.generate(Project2.Part3::upperTotal, 20));

        test = new JavaFunctionTest(this, "upper-bonus", 1, this::testUpperBonus);
        test.generateData(Project2.generate(Project2.Part3::upperBonus, 20));

        test = new JavaFunctionTest(this, "lower-total", 1, this::testLowerTotal);
        test.generateData(Project2.generate(Project2.Part3::lowerTotal, 20));

        test = new JavaFunctionTest(this, "total-score", 1, this::testTotalScore);
        test.generateData(Project2.generate(Project2.Part3::totalScore, 20));

        test =
                new JavaFunctionTest(
                        this, "calculate-upper-category", 1, this::testCalculateUpperCategory);
        test.generateData(Project2.generate(Project2.Part3::calculateUpperCategory, 40));

        test =
                new JavaFunctionTest(
                        this, "calculate-three-of-a-kind", 1, this::testCalculateThreeOfAKind);
        test.generateData(Project2.generate(Project2.Part3::calculateThreeOfAKind, 40));

        test =
                new JavaFunctionTest(
                        this, "calculate-four-of-a-kind", 1, this::testCalculateFourOfAKind);
        test.generateData(Project2.generate(Project2.Part3::calculateFourOfAKind, 40));

        test = new JavaFunctionTest(this, "calculate-full-house", 1, this::testCalculateFullHouse);
        test.generateData(Project2.generate(Project2.Part3::calculateFullHouse, 40));

        test =
                new JavaFunctionTest(
                        this, "calculate-small-straight", 1, this::testCalculateSmallStraight);
        test.generateData(Project2.generate(Project2.Part3::calculateSmallStraight, 40));

        test =
                new JavaFunctionTest(
                        this, "calculate-large-straight", 1, this::testCalculateLargeStraight);
        test.generateData(Project2.generate(Project2.Part3::calculateLargeStraight, 40));

        test = new JavaFunctionTest(this, "calculate-yahtzee", 1, this::testCalculateYahtzee);
        test.generateData(Project2.generate(Project2.Part3::calculateYahtzee, 40));

        test = new JavaFunctionTest(this, "calculate-chance", 1, this::testCalculateChance);
        test.generateData(Project2.generate(Project2.Part3::calculateChance, 40));
    }

    private List<String> testGame(Project2Input input) {
        student.project2.Dice.setSeed(input.seed());
        student.project2.part3.DiceGame.game(new Scanner(input.userInputScanner()));
        return Collections.emptyList();
    }

    private List<String> testRerollPhase(Project2Input input) {
        student.project2.Dice.setSeed(input.seed());
        student.project2.part3.DiceGame.rerollPhase(
                new Scanner(input.userInputScanner()), input.diceArray());
        return Collections.emptyList();
    }

    private List<String> testScorePhase(Project2Input input) {
        student.project2.part3.DiceGame.scorePhase(
                new Scanner(input.userInputScanner()),
                input.diceArray(),
                input.scoresArray(),
                input.scoreCategoriesUsed(),
                input.scoreCategoryNames());
        return Collections.emptyList();
    }

    private List<String> testRollAllDice(Project2Input input) {
        student.project2.Dice.setSeed(input.seed());
        student.project2.part3.DiceGame.rollAllDice(input.diceArray());
        return Collections.emptyList();
    }

    private List<String> testRollSomeDice(Project2Input input) {
        student.project2.Dice.setSeed(input.seed());
        student.project2.part3.DiceGame.rollSomeDice(input.diceArray(), input.rerollLabels());
        return Collections.emptyList();
    }

    private List<String> testDiceString(Project2Input input) {
        String returnValue = student.project2.part3.DiceGame.diceString(input.diceArray());
        return Arrays.asList(returnValue.split("\n"));
    }

    private List<String> testScoreString(Project2Input input) {
        String returnValue =
                student.project2.part3.DiceGame.scoreString(
                        input.scoresArray(),
                        input.scoreCategoriesUsed(),
                        input.scoreCategoryNames(),
                        input.diceArray());
        return Arrays.asList(returnValue.split("\n"));
    }

    private List<String> testCountDice(Project2Input input) {
        return List.of(
                ""
                        + student.project2.part3.DiceGame.countDice(
                                input.diceArray(), input.dieValue()));
    }

    private List<String> testCalculateDiceScore(Project2Input input) {
        return List.of(
                ""
                        + student.project2.part3.DiceGame.calculateDiceScore(
                                input.diceArray(), input.scoreCategoryIndex()));
    }

    private List<String> testUpperTotal(Project2Input input) {
        return List.of("" + student.project2.part3.DiceGame.upperTotal(input.scoresArray()));
    }

    private List<String> testUpperBonus(Project2Input input) {
        return List.of("" + student.project2.part3.DiceGame.upperBonus(input.scoresArray()));
    }

    private List<String> testLowerTotal(Project2Input input) {
        return List.of("" + student.project2.part3.DiceGame.lowerTotal(input.scoresArray()));
    }

    private List<String> testTotalScore(Project2Input input) {
        return List.of("" + student.project2.part3.DiceGame.totalScore(input.scoresArray()));
    }

    private List<String> testCalculateUpperCategory(Project2Input input) {
        return List.of(
                ""
                        + student.project2.part3.DiceGame.calculateUpperCategory(
                                input.diceArray(), input.scoreCategoryIndex()));
    }

    private List<String> testCalculateThreeOfAKind(Project2Input input) {
        return List.of(
                "" + student.project2.part3.DiceGame.calculateThreeOfAKind(input.diceArray()));
    }

    private List<String> testCalculateFourOfAKind(Project2Input input) {
        return List.of(
                "" + student.project2.part3.DiceGame.calculateFourOfAKind(input.diceArray()));
    }

    private List<String> testCalculateFullHouse(Project2Input input) {
        return List.of("" + student.project2.part3.DiceGame.calculateFullHouse(input.diceArray()));
    }

    private List<String> testCalculateSmallStraight(Project2Input input) {
        return List.of(
                "" + student.project2.part3.DiceGame.calculateSmallStraight(input.diceArray()));
    }

    private List<String> testCalculateLargeStraight(Project2Input input) {
        return List.of(
                "" + student.project2.part3.DiceGame.calculateLargeStraight(input.diceArray()));
    }

    private List<String> testCalculateYahtzee(Project2Input input) {
        return List.of("" + student.project2.part3.DiceGame.calculateYahtzee(input.diceArray()));
    }

    private List<String> testCalculateChance(Project2Input input) {
        return List.of("" + student.project2.part3.DiceGame.calculateChance(input.diceArray()));
    }
}
