package projecttests.util;

import projecttests.logging.Logger;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Common operations inloving paths and files. */
public final class FileIO {
    public static boolean exactRelativePathExists(Path path) {
        Path workingDir = FileSystems.getDefault().getPath(".").toAbsolutePath().normalize();
        try {
            Path realPath = workingDir.relativize(path.toRealPath());
            return path.normalize().toString().equals(realPath.toString());
        } catch (IOException e) {
            return false;
        }
    }

    public static List<String> loadOrElse(Path path, List<String> orElse) {
        try (Stream<String> stream = Files.lines(path)) {
            List<String> list = stream.toList();
            Logger.infoFormat("Read lines from %s:\n%s", path, Strings.join(list, "\n"));
            return list;
        } catch (IOException e) {
            Logger.error(e, "IOException while loading file at " + path);
            return orElse;
        }
    }

    public static <X extends Throwable> List<String> loadOrElseThrow(
            Path path, Supplier<? extends X> exceptionSupplier) throws X {
        try (Stream<String> stream = Files.lines(path)) {
            List<String> list = stream.toList();
            Logger.infoFormat("Read lines from %s:\n%s", path, Strings.join(list, "\n"));
            return list;
        } catch (IOException e) {
            Logger.error(e, "IOException while loading file at " + path);
            throw exceptionSupplier.get();
        }
    }

    public static void zip(Path zipPath, List<Path> contents) throws IOException {
        try (ZipOutputStream zipOut =
                new ZipOutputStream(new FileOutputStream(zipPath.toAbsolutePath().toString()))) {
            for (Path p : contents) {
                File file = new File(p.toString());
                zipOut.putNextEntry(new ZipEntry(file.getPath().replaceAll("\\\\", "/")));
                Files.copy(p, zipOut);
            }
        }
    }
}
