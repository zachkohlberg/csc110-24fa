package projecttests.commands;

import projecttests.*;
import projecttests.logging.Logger;
import projecttests.projects.Projects;
import projecttests.testing.TestResult;
import projecttests.testing.browser.ResultsBrowser;
import projecttests.util.Command;
import projecttests.util.CommandArgs;
import projecttests.util.FileIO;
import projecttests.util.Project;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/** Runs the tests for one or more projects. */
public class Test implements Command<Main> {
    @Override
    public void run(Main context, CommandArgs args) throws TestingException {
        Logger.info("test command");

        boolean skipResults = args.flagSet("skip-results");

        List<Project> projects = new ArrayList<>();
        if (args.size() == 0) {
            for (Project project : Projects.all()) {
                boolean testable = true;
                for (Path p : project.projectFilePaths()) {
                    if (FileIO.loadOrElse(p, null) == null) {
                        testable = false;
                    }
                }

                if (testable) {
                    List<String> passData = FileIO.loadOrElse(project.recordFilePath(), null);

                    if (passData == null
                            || passData.size() < 2
                            || !passData.get(0).equalsIgnoreCase("PASS")) {
                        projects.add(project);
                    }
                }
            }
        } else {
            for (String arg : args) {
                Project p = Projects.getById(arg);
                if (p == null) {
                    throw new TestingException(arg + " is not a valid project");
                }
                projects.add(p);
            }
        }

        Scanner in = new Scanner(System.in);
        for (Project p : projects) {
            TestResult result = p.test();

            Logger.info("Saving overall result");

            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);

            try {
                Files.createDirectories(p.recordFilePath().getParent());
                Files.write(
                        p.recordFilePath(),
                        List.of(result.overallPass() ? "PASS" : "FAIL", timestamp),
                        StandardOpenOption.CREATE,
                        StandardOpenOption.TRUNCATE_EXISTING);
            } catch (IOException e) {
                Logger.error(e, "IOException while recording test result").print();
            }

            if (!skipResults) {
                ResultsBrowser browser = new ResultsBrowser(p, result);
                browser.run(in);
            }
        }
    }

    @Override
    public String id() {
        return "test";
    }

    @Override
    public String help() {
        return """
Tests a project or a group of projects.

USAGE: {COMMAND} test PROJECT [PROJECT]...

Valid project names: 1.1, 1.2, 2.1, 2.2, 2.3

Flags:
    --skip-results
        Don't show the results browser after the test is finished. This will
        still record whether the test passed or failed for the status and pack
        commands.

Examples:

{COMMAND} test 1.1
{COMMAND} test 1.2
{COMMAND} test 1.1 1.2 2.1 3.1
"""
                .replace("{COMMAND}", Main.COMMAND);
    }
}
